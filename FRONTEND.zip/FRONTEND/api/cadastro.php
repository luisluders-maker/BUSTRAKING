<?php
// api/cadastro.php — cria uma conta de usuário COMUM (perfil USUARIO).
// O perfil é sempre definido aqui no servidor: nunca vem do navegador.

require __DIR__ . '/conexao.php';
require __DIR__ . '/auth.php';

exigir_metodo('POST');
$entrada = entrada_json();

$nome  = campo_texto($entrada, 'nome');
$email = strtolower(campo_texto($entrada, 'email'));
$senha = is_string($entrada['senha'] ?? null) ? $entrada['senha'] : '';

if ($nome === '' || mb_strlen($nome) > 150) {
    responder(['erro' => 'Informe seu nome (até 150 caracteres).'], 422);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) {
    responder(['erro' => 'Informe um e-mail válido.'], 422);
}
if (mb_strlen($senha) < 8) {
    responder(['erro' => 'A senha precisa ter pelo menos 8 caracteres.'], 422);
}
if (strlen($senha) > 72) {   // limite do bcrypt
    responder(['erro' => 'A senha pode ter no máximo 72 caracteres.'], 422);
}

try {
    $busca = $pdo->prepare('SELECT 1 FROM Usuario WHERE Email = ?');
    $busca->execute([$email]);
    if ($busca->fetchColumn()) {
        responder(['erro' => 'Já existe uma conta com esse e-mail.'], 409);
    }

    $perfil = $pdo->query("SELECT ID_Perfil FROM Perfil WHERE NM_Perfil = 'USUARIO'")->fetchColumn();
    if (!$perfil) {
        throw new RuntimeException('Perfil USUARIO não encontrado na tabela Perfil.');
    }

    // Guardamos só o HASH da senha (60 caracteres), nunca a senha em si.
    $hash = password_hash($senha, PASSWORD_BCRYPT);

    $insere = $pdo->prepare('INSERT INTO Usuario (Nome, Email, Senha, ID_Perfil) VALUES (?, ?, ?, ?)');
    $insere->execute([$nome, $email, $hash, $perfil]);

    responder(['sucesso' => true], 201);

} catch (PDOException $e) {
    if ($e->getCode() === '23000') {   // e-mail repetido (duas contas ao mesmo tempo)
        responder(['erro' => 'Já existe uma conta com esse e-mail.'], 409);
    }
    error_log('cadastro.php: ' . $e->getMessage());
    responder(['erro' => 'Não foi possível criar a conta.'], 500);
} catch (Throwable $e) {
    error_log('cadastro.php: ' . $e->getMessage());
    responder(['erro' => 'Não foi possível criar a conta.'], 500);
}
