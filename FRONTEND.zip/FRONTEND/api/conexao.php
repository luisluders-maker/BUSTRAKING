<?php
// api/conexao.php — conexão com o MySQL do XAMPP.
// Todos os outros arquivos da pasta api fazem: require __DIR__ . '/conexao.php';

$DB_HOST = 'localhost';
$DB_NOME = 'bustrack';   // nome do banco no phpMyAdmin
$DB_USER = 'root';       // usuário padrão do XAMPP
$DB_PASS = '';           // senha padrão do XAMPP: vazia

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NOME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    // O detalhe do erro vai para o log do Apache (xampp/apache/logs/error.log),
    // e não para o navegador.
    error_log('Conexão com o banco falhou: ' . $e->getMessage());
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['erro' => 'Falha na conexão com o banco de dados.']);
    exit;
}
