<?php
// api/admin/horarios.php — horários de UMA linha. Só ADMIN.
// GET  ?linha=ID -> horários agrupados por dia e sentido
// POST JSON "acao": adicionar | remover | alterar  (sempre só para a linha informada)
//
// Os horários são compartilhados entre linhas (tabela horarios), então nunca
// editamos o registro em si: mexemos só na ligação da linha (horarios_linhas).

require __DIR__ . '/../conexao.php';
require __DIR__ . '/../auth.php';

exigir_admin();

const DIAS     = ['SEGUNDA_SEXTA', 'SABADO', 'DOMINGO', 'FERIADO'];
const SENTIDOS = ['TERMINAL', 'BAIRRO'];

function hora_valida(string $h): bool
{
    return (bool) preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $h);
}

/** Acha o horário (hora+dia+sentido) ou cria se ainda não existir. */
function obter_horario(PDO $pdo, string $hora, string $dia, string $sentido): int
{
    $busca = $pdo->prepare('SELECT ID_Horario FROM horarios WHERE HR_Saida = ? AND Tipo_Dia = ? AND Sentido = ?');
    $busca->execute([$hora, $dia, $sentido]);
    $id = $busca->fetchColumn();
    if ($id !== false) {
        return (int) $id;
    }
    try {
        $pdo->prepare('INSERT INTO horarios (HR_Saida, Tipo_Dia, Sentido) VALUES (?, ?, ?)')->execute([$hora, $dia, $sentido]);
        return (int) $pdo->lastInsertId();
    } catch (PDOException $e) {
        if ($e->getCode() !== '23000') {
            throw $e;
        }
        $busca->execute([$hora, $dia, $sentido]);   // alguém criou ao mesmo tempo
        return (int) $busca->fetchColumn();
    }
}

/** Desfaz a ligação da linha com o horário; apaga o horário se ficou sem nenhuma linha. */
function desligar(PDO $pdo, int $linha, int $horario): void
{
    $pdo->prepare('DELETE FROM horarios_linhas WHERE ID_Horarios = ? AND ID_Linha = ?')->execute([$horario, $linha]);
    $pdo->prepare('DELETE FROM horarios WHERE ID_Horario = ?
                    AND NOT EXISTS (SELECT 1 FROM horarios_linhas WHERE ID_Horarios = ?)')->execute([$horario, $horario]);
}

function linha_existe(PDO $pdo, int $linha): void
{
    $q = $pdo->prepare('SELECT 1 FROM linhas WHERE ID_Linha = ?');
    $q->execute([$linha]);
    if (!$q->fetchColumn()) {
        responder(['erro' => 'Linha não encontrada.'], 404);
    }
}

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $linha = (int) ($_GET['linha'] ?? 0);
        linha_existe($pdo, $linha);

        $dias = [];
        foreach (DIAS as $d) {
            $dias[$d] = ['TERMINAL' => [], 'BAIRRO' => []];
        }
        $q = $pdo->prepare('SELECT h.Tipo_Dia, h.Sentido, h.HR_Saida
                              FROM horarios h JOIN horarios_linhas hl ON hl.ID_Horarios = h.ID_Horario
                             WHERE hl.ID_Linha = ? ORDER BY h.HR_Saida');
        $q->execute([$linha]);
        foreach ($q as $r) {
            if (isset($dias[$r['Tipo_Dia']][$r['Sentido']])) {
                $dias[$r['Tipo_Dia']][$r['Sentido']][] = $r['HR_Saida'];
            }
        }
        responder(['dias' => $dias]);
    }

    exigir_metodo('POST');
    $e       = entrada_json();
    $acao    = campo_texto($e, 'acao');
    $linha   = (int) ($e['linha'] ?? 0);
    $dia     = campo_texto($e, 'dia');
    $sentido = campo_texto($e, 'sentido');
    $hora    = campo_texto($e, 'hora');

    if (!in_array($dia, DIAS, true) || !in_array($sentido, SENTIDOS, true) || !hora_valida($hora)) {
        responder(['erro' => 'Informe dia, sentido e um horário no formato HH:MM.'], 422);
    }
    linha_existe($pdo, $linha);

    if ($acao === 'adicionar') {
        $h = obter_horario($pdo, $hora, $dia, $sentido);
        $pdo->prepare('INSERT IGNORE INTO horarios_linhas (ID_Horarios, ID_Linha) VALUES (?, ?)')->execute([$h, $linha]);
        responder(['sucesso' => true], 201);
    }

    // remover e alterar partem do horário atual da linha
    $busca = $pdo->prepare('SELECT ID_Horario FROM horarios WHERE HR_Saida = ? AND Tipo_Dia = ? AND Sentido = ?');
    $busca->execute([$hora, $dia, $sentido]);
    $atual = $busca->fetchColumn();
    if ($atual === false) {
        responder(['erro' => 'Horário não encontrado.'], 404);
    }

    if ($acao === 'remover') {
        desligar($pdo, $linha, (int) $atual);
        responder(['sucesso' => true]);
    }

    if ($acao === 'alterar') {
        $nova = campo_texto($e, 'nova');
        if (!hora_valida($nova)) {
            responder(['erro' => 'O novo horário precisa estar no formato HH:MM.'], 422);
        }
        $pdo->beginTransaction();
        $novo = obter_horario($pdo, $nova, $dia, $sentido);
        $pdo->prepare('INSERT IGNORE INTO horarios_linhas (ID_Horarios, ID_Linha) VALUES (?, ?)')->execute([$novo, $linha]);
        if ($novo !== (int) $atual) {
            desligar($pdo, $linha, (int) $atual);
        }
        $pdo->commit();
        responder(['sucesso' => true]);
    }

    responder(['erro' => 'Ação inválida.'], 422);

} catch (Throwable $ex) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('admin/horarios.php: ' . $ex->getMessage());
    responder(['erro' => 'Erro ao acessar o banco de dados.'], 500);
}
