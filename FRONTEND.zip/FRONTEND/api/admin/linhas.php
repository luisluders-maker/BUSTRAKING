<?php
// api/admin/linhas.php — lista, cria, edita, ativa/desativa e exclui linhas. Só ADMIN.
// GET  -> lista todas as linhas (inclusive as desativadas)
// POST -> JSON com "acao": criar | editar | status | excluir

require __DIR__ . '/../conexao.php';
require __DIR__ . '/../auth.php';

exigir_admin();   // vale para GET e POST

function validar_linha(array $e): array
{
    $numero = $e['numero'] ?? null;
    $nome   = campo_texto($e, 'nome');
    if (!is_numeric($numero) || (int) $numero < 1 || (int) $numero > 99999 || (string) (int) $numero !== trim((string) $numero)) {
        responder(['erro' => 'Informe o número da linha (inteiro, de 1 a 99999).'], 422);
    }
    if ($nome === '' || mb_strlen($nome) > 150) {
        responder(['erro' => 'Informe o nome da linha (até 150 caracteres).'], 422);
    }
    return [(int) $numero, $nome];
}

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $lista = $pdo->query(
            "SELECT l.ID_Linha, l.NUM_Linha, l.Nome, l.Status,
                    (SELECT COUNT(*) FROM horarios_linhas hl WHERE hl.ID_Linha = l.ID_Linha) AS horarios,
                    (SELECT COUNT(DISTINCT ppl.ID_Parada) FROM pontos_parada_linhas ppl WHERE ppl.ID_Linhas = l.ID_Linha) AS pontos
               FROM linhas l
              ORDER BY l.NUM_Linha"
        )->fetchAll();
        responder(['linhas' => array_map(fn($l) => [
            'id'       => (int) $l['ID_Linha'],
            'numero'   => (int) $l['NUM_Linha'],
            'nome'     => $l['Nome'],
            'status'   => (int) $l['Status'],
            'horarios' => (int) $l['horarios'],
            'pontos'   => (int) $l['pontos'],
        ], $lista)]);
    }

    exigir_metodo('POST');
    $e    = entrada_json();
    $acao = campo_texto($e, 'acao');
    $id   = (int) ($e['id'] ?? 0);

    if ($acao === 'criar') {
        [$numero, $nome] = validar_linha($e);
        $pdo->prepare('INSERT INTO linhas (NUM_Linha, Nome, Status) VALUES (?, ?, 1)')->execute([$numero, $nome]);
        responder(['sucesso' => true, 'id' => (int) $pdo->lastInsertId()], 201);
    }

    if ($id < 1) {
        responder(['erro' => 'Linha inválida.'], 422);
    }

    if ($acao === 'editar') {
        [$numero, $nome] = validar_linha($e);
        $pdo->prepare('UPDATE linhas SET NUM_Linha = ?, Nome = ? WHERE ID_Linha = ?')->execute([$numero, $nome, $id]);
        responder(['sucesso' => true]);
    }

    if ($acao === 'status') {
        $status = !empty($e['status']) ? 1 : 0;
        $pdo->prepare('UPDATE linhas SET Status = ? WHERE ID_Linha = ?')->execute([$status, $id]);
        responder(['sucesso' => true, 'status' => $status]);
    }

    if ($acao === 'excluir') {
        // Apaga também horários, pontos e veículos ligados a ela (ON DELETE CASCADE).
        // Por segurança, exige digitar o número da linha.
        $busca = $pdo->prepare('SELECT NUM_Linha FROM linhas WHERE ID_Linha = ?');
        $busca->execute([$id]);
        $num = $busca->fetchColumn();
        if ($num === false) {
            responder(['erro' => 'Linha não encontrada.'], 404);
        }
        if ((string) ($e['confirmar'] ?? '') !== (string) $num) {
            responder(['erro' => 'Confirmação incorreta: digite o número da linha.'], 422);
        }
        $pdo->prepare('DELETE FROM linhas WHERE ID_Linha = ?')->execute([$id]);
        responder(['sucesso' => true]);
    }

    responder(['erro' => 'Ação inválida.'], 422);

} catch (PDOException $ex) {
    if ($ex->getCode() === '23000') {
        responder(['erro' => 'Já existe uma linha com esse número.'], 409);
    }
    error_log('admin/linhas.php: ' . $ex->getMessage());
    responder(['erro' => 'Erro ao acessar o banco de dados.'], 500);
} catch (Throwable $ex) {
    error_log('admin/linhas.php: ' . $ex->getMessage());
    responder(['erro' => 'Erro inesperado.'], 500);
}
