<?php
// api/admin/usuarios.php — lista os usuários COMUNS (perfil USUARIO). Só ADMIN acessa.
// A checagem é feita aqui no servidor, em toda chamada: esconder o botão no JavaScript não protege nada.

require __DIR__ . '/../conexao.php';
require __DIR__ . '/../auth.php';

exigir_metodo('GET');
exigir_admin();   // 401 se não estiver logado, 403 se não for ADMIN

try {
    $lista = $pdo->query(
        "SELECT u.ID_Usuario, u.Nome, u.Email
           FROM Usuario u
           JOIN Perfil p ON p.ID_Perfil = u.ID_Perfil
          WHERE p.NM_Perfil = 'USUARIO'
          ORDER BY u.Nome"
    )->fetchAll();   // a coluna Senha nunca sai do servidor

    $usuarios = array_map(fn($u) => [
        'id'    => (int) $u['ID_Usuario'],
        'nome'  => $u['Nome'],
        'email' => $u['Email'],
    ], $lista);

    responder(['usuarios' => $usuarios]);

} catch (Throwable $e) {
    error_log('admin/usuarios.php: ' . $e->getMessage());
    responder(['erro' => 'Não foi possível listar os usuários.'], 500);
}
