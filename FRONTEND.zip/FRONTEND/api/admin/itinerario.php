<?php
// api/admin/itinerario.php — pontos (e a ordem deles) de uma linha, por sentido. Só ADMIN.
// GET  ?linha=ID -> {"sentidos": {"TERMINAL": [{id, nome}, ...], "BAIRRO": [...]}}
// POST JSON {"acao":"salvar","linha":ID,"sentido":"TERMINAL","pontos":[id, id, ...]}
//   Substitui o itinerário daquele sentido pela lista enviada (a ordem da lista vira a Ordem 1, 2, 3...),
//   tudo numa transação: ou grava tudo, ou nada muda.

require __DIR__ . '/../conexao.php';
require __DIR__ . '/../auth.php';

exigir_admin();

const SENTIDOS   = ['TERMINAL', 'BAIRRO'];
const MAX_PONTOS = 300;

function linha_existe(PDO $pdo, int $linha): void
{
    $q = $pdo->prepare('SELECT 1 FROM linhas WHERE ID_Linha = ?');
    $q->execute([$linha]);
    if (!$q->fetchColumn()) {
        responder(['erro' => 'Linha não encontrada.'], 404);
    }
}

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $linha = (int) ($_GET['linha'] ?? 0);
        linha_existe($pdo, $linha);

        $sentidos = ['TERMINAL' => [], 'BAIRRO' => []];
        $q = $pdo->prepare(
            'SELECT ppl.Sentido, p.ID_Parada, p.NM_Parada
               FROM pontos_parada_linhas ppl
               JOIN pontos_parada p ON p.ID_Parada = ppl.ID_Parada
              WHERE ppl.ID_Linhas = ?
              ORDER BY ppl.Sentido, ppl.Ordem'
        );
        $q->execute([$linha]);
        foreach ($q as $r) {
            if (isset($sentidos[$r['Sentido']])) {
                $sentidos[$r['Sentido']][] = ['id' => (int) $r['ID_Parada'], 'nome' => $r['NM_Parada']];
            }
        }
        responder(['sentidos' => $sentidos]);
    }

    exigir_metodo('POST');
    $e       = entrada_json();
    $linha   = (int) ($e['linha'] ?? 0);
    $sentido = campo_texto($e, 'sentido');
    $pontos  = $e['pontos'] ?? null;

    if (campo_texto($e, 'acao') !== 'salvar' || !in_array($sentido, SENTIDOS, true) || !is_array($pontos)) {
        responder(['erro' => 'Requisição inválida.'], 422);
    }
    if (count($pontos) > MAX_PONTOS) {
        responder(['erro' => 'Um itinerário pode ter no máximo ' . MAX_PONTOS . ' pontos.'], 422);
    }
    $lista = [];
    foreach ($pontos as $p) {
        if (!(is_int($p) || (is_string($p) && ctype_digit($p))) || (int) $p < 1) {
            responder(['erro' => 'Lista de pontos inválida.'], 422);
        }
        $lista[] = (int) $p;   // pode repetir: algumas rotas passam duas vezes pelo mesmo ponto
    }
    linha_existe($pdo, $linha);

    // Todos os pontos enviados precisam existir.
    $unicos = array_values(array_unique($lista));
    if ($unicos) {
        $marcas = implode(',', array_fill(0, count($unicos), '?'));
        $conta  = $pdo->prepare("SELECT COUNT(*) FROM pontos_parada WHERE ID_Parada IN ($marcas)");
        $conta->execute($unicos);
        if ((int) $conta->fetchColumn() !== count($unicos)) {
            responder(['erro' => 'Algum ponto da lista não existe mais. Recarregue a página.'], 422);
        }
    }

    $pdo->beginTransaction();
    $pdo->prepare('DELETE FROM pontos_parada_linhas WHERE ID_Linhas = ? AND Sentido = ?')->execute([$linha, $sentido]);
    $insere = $pdo->prepare('INSERT INTO pontos_parada_linhas (ID_Linhas, ID_Parada, Sentido, Ordem) VALUES (?, ?, ?, ?)');
    foreach ($lista as $i => $parada) {
        $insere->execute([$linha, $parada, $sentido, $i + 1]);
    }
    $pdo->commit();

    responder(['sucesso' => true, 'total' => count($lista)]);

} catch (Throwable $ex) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('admin/itinerario.php: ' . $ex->getMessage());
    responder(['erro' => 'Erro ao acessar o banco de dados.'], 500);
}
