<?php
// api/admin/pontos.php — lista, cria, edita e exclui pontos de parada. Só ADMIN.
// GET  ?q=texto&pagina=N -> 20 pontos por página (busca por nome ou endereço)
// POST JSON "acao": criar | editar | excluir

require __DIR__ . '/../conexao.php';
require __DIR__ . '/../auth.php';

exigir_admin();

const POR_PAGINA = 20;

/** Coordenada opcional: vazio vira NULL; aceita vírgula decimal. */
function coordenada($v, float $min, float $max, string $nome): ?float
{
    if ($v === null || $v === '') {
        return null;
    }
    if (is_string($v)) {
        $v = str_replace(',', '.', trim($v));
    }
    if (!is_numeric($v) || (float) $v < $min || (float) $v > $max) {
        responder(['erro' => "$nome inválida (use um número entre $min e $max)."], 422);
    }
    return round((float) $v, 6);
}

function validar_ponto(array $e): array
{
    $nome     = campo_texto($e, 'nome');
    $endereco = campo_texto($e, 'endereco');
    if ($nome === '' || mb_strlen($nome) > 100) {
        responder(['erro' => 'Informe o nome do ponto (até 100 caracteres).'], 422);
    }
    if (mb_strlen($endereco) > 200) {
        responder(['erro' => 'O endereço pode ter até 200 caracteres.'], 422);
    }
    $lat = coordenada($e['latitude'] ?? null, -90, 90, 'Latitude');
    $lng = coordenada($e['longitude'] ?? null, -180, 180, 'Longitude');
    if (($lat === null) !== ($lng === null)) {
        responder(['erro' => 'Preencha latitude e longitude juntas, ou deixe as duas vazias.'], 422);
    }
    return [$nome, $endereco === '' ? null : $endereco, $lat, $lng];
}

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $q      = trim((string) ($_GET['q'] ?? ''));
        $pagina = max(1, (int) ($_GET['pagina'] ?? 1));
        $filtro = '';
        $args   = [];
        if ($q !== '') {
            $like   = '%' . addcslashes($q, '%_\\') . '%';
            $filtro = 'WHERE p.NM_Parada LIKE ? OR p.Endereco LIKE ?';
            $args   = [$like, $like];
        }

        $total = $pdo->prepare("SELECT COUNT(*) FROM pontos_parada p $filtro");
        $total->execute($args);
        $total = (int) $total->fetchColumn();

        $offset = ($pagina - 1) * POR_PAGINA;
        $lista  = $pdo->prepare(
            "SELECT p.ID_Parada, p.NM_Parada, p.Endereco, p.Latitude, p.Longitude,
                    (SELECT COUNT(DISTINCT ppl.ID_Linhas) FROM pontos_parada_linhas ppl WHERE ppl.ID_Parada = p.ID_Parada) AS linhas
               FROM pontos_parada p $filtro
              ORDER BY p.NM_Parada
              LIMIT " . POR_PAGINA . " OFFSET $offset"
        );
        $lista->execute($args);

        responder([
            'total'     => $total,
            'pagina'    => $pagina,
            'paginas'   => max(1, (int) ceil($total / POR_PAGINA)),
            'pontos'    => array_map(fn($p) => [
                'id'        => (int) $p['ID_Parada'],
                'nome'      => $p['NM_Parada'],
                'endereco'  => $p['Endereco'] ?? '',
                'latitude'  => $p['Latitude'] !== null ? (float) $p['Latitude'] : null,
                'longitude' => $p['Longitude'] !== null ? (float) $p['Longitude'] : null,
                'linhas'    => (int) $p['linhas'],
            ], $lista->fetchAll()),
        ]);
    }

    exigir_metodo('POST');
    $e    = entrada_json();
    $acao = campo_texto($e, 'acao');
    $id   = (int) ($e['id'] ?? 0);

    if ($acao === 'criar') {
        [$nome, $end, $lat, $lng] = validar_ponto($e);
        $pdo->prepare('INSERT INTO pontos_parada (NM_Parada, Endereco, Latitude, Longitude) VALUES (?, ?, ?, ?)')
            ->execute([$nome, $end, $lat, $lng]);
        responder(['sucesso' => true, 'id' => (int) $pdo->lastInsertId()], 201);
    }

    if ($id < 1) {
        responder(['erro' => 'Ponto inválido.'], 422);
    }

    if ($acao === 'editar') {
        [$nome, $end, $lat, $lng] = validar_ponto($e);
        $pdo->prepare('UPDATE pontos_parada SET NM_Parada = ?, Endereco = ?, Latitude = ?, Longitude = ? WHERE ID_Parada = ?')
            ->execute([$nome, $end, $lat, $lng, $id]);
        responder(['sucesso' => true]);
    }

    if ($acao === 'excluir') {
        // Só exclui ponto que não está em nenhuma linha (senão quebraria os itinerários).
        $uso = $pdo->prepare('SELECT COUNT(DISTINCT ID_Linhas) FROM pontos_parada_linhas WHERE ID_Parada = ?');
        $uso->execute([$id]);
        $n = (int) $uso->fetchColumn();
        if ($n > 0) {
            responder(['erro' => "Este ponto faz parte de $n linha(s) e não pode ser excluído. Tire-o dos itinerários primeiro."], 409);
        }
        $pdo->prepare('DELETE FROM pontos_parada WHERE ID_Parada = ?')->execute([$id]);
        responder(['sucesso' => true]);
    }

    responder(['erro' => 'Ação inválida.'], 422);

} catch (Throwable $ex) {
    error_log('admin/pontos.php: ' . $ex->getMessage());
    responder(['erro' => 'Erro ao acessar o banco de dados.'], 500);
}
