<?php
// api/sessao.php — diz quem está logado (ou null). O site usa isto no cabeçalho.

require __DIR__ . '/auth.php';

exigir_metodo('GET');
responder(['usuario' => usuario_atual()]);
