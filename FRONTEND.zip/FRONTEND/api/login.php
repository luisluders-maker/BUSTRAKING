<?php
// api/login.php — confere e-mail e senha e abre a sessão.

require __DIR__ . '/conexao.php';
require __DIR__ . '/auth.php';

exigir_metodo('POST');
$entrada = entrada_json();

$email = strtolower(campo_texto($entrada, 'email'));
$senha = is_string($entrada['senha'] ?? null) ? $entrada['senha'] : '';

if ($email === '' || $senha === '' || strlen($senha) > 1000) {
    responder(['erro' => 'E-mail ou senha incorretos.'], 401);
}

try {
    $busca = $pdo->prepare(
        'SELECT u.ID_Usuario, u.Nome, u.Email, u.Senha, p.NM_Perfil
           FROM Usuario u
           JOIN Perfil p ON p.ID_Perfil = u.ID_Perfil
          WHERE u.Email = ?'
    );
    $busca->execute([$email]);
    $usuario = $busca->fetch();

    // Mesmo quando o e-mail não existe, conferimos um hash qualquer: assim o
    // tempo de resposta não revela se o e-mail está cadastrado.
    $hashFalso = '$2y$10$08oZdxZF7N6pOYCWLJaMR.MKbqPWgjiNi6aBujquSQGqnV6/CAdAO';
    $senhaOk   = password_verify($senha, $usuario['Senha'] ?? $hashFalso);

    if (!$usuario || !$senhaOk) {
        // Mensagem igual nos dois casos, para não dizer qual dos dois errou.
        responder(['erro' => 'E-mail ou senha incorretos.'], 401);
    }

    iniciar_sessao();
    session_regenerate_id(true);   // novo "crachá" a cada login
    $_SESSION['usuario'] = [
        'id'     => (int) $usuario['ID_Usuario'],
        'nome'   => $usuario['Nome'],
        'email'  => $usuario['Email'],
        'perfil' => $usuario['NM_Perfil'],   // USUARIO ou ADMIN
    ];

    responder(['sucesso' => true, 'usuario' => $_SESSION['usuario']]);

} catch (Throwable $e) {
    error_log('login.php: ' . $e->getMessage());
    responder(['erro' => 'Não foi possível entrar agora. Tente novamente.'], 500);
}
