-- ============================================================
-- BUSTRACKING — Perfil MOTORISTA (quem envia a posição do ônibus)
-- Importe no phpMyAdmin com o SEU banco selecionado (aba "Importar").
-- Não apaga nada e pode rodar mais de uma vez.
--
-- Cria:
--   * o perfil MOTORISTA
--   * um motorista de teste:
--       motorista@bustracking.example   senha: motorista123
-- (troque a senha antes de publicar o site)
--
-- Para transformar outro usuário em motorista: entre como ADMIN,
-- abra o Painel admin e troque o perfil dele na tabela.
-- ============================================================
SET NAMES utf8mb4;

INSERT INTO Perfil (NM_Perfil)
SELECT 'MOTORISTA' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM Perfil WHERE NM_Perfil = 'MOTORISTA');

INSERT INTO Usuario (Nome, Email, Senha, ID_Estado, ID_Perfil)
SELECT 'Motorista Teste', 'motorista@bustracking.example',
       '$2y$10$MMUDeg/YxctLGPhiVYueGuIlpU8A7b8.aZRhvC/y2Bhncr3X83uCS',
       e.ID_Estado, p.ID_Perfil
FROM Perfil p
LEFT JOIN Estado e ON e.NM_Estado = 'São Paulo'
WHERE p.NM_Perfil = 'MOTORISTA'
  AND NOT EXISTS (SELECT 1 FROM Usuario WHERE Email = 'motorista@bustracking.example')
LIMIT 1;
