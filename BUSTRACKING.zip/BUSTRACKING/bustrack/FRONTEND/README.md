BUSTRACKING — versão estática HTML/CSS3

Estrutura:
- index.html              Tela inicial
- rastrear.html           Rastreamento ao vivo (mapa real)
- motorista.html          Modo motorista (envia o GPS do celular)
- itinerarios.html        Itinerários
- horarios.html           Horários
- login.html              Login
- cadastro.html           Cadastro
- components/header.html  Header compartilhado
- css/styles.css          Estilos globais
- js/main.js               Carregamento do header e menu mobile

Observação:
O rastreio ao vivo usa o GPS do celular do motorista (veja LEIA-ME_RASTREIO.md); as posições ficam só em memória/arquivo temporário, nunca no banco.
Para abrir, mantenha a estrutura de pastas e abra index.html em um servidor local (Live Server, por exemplo).




### Rotas específicas
- `/rastrear.html` — sidebar de ônibus + mapa live + popup de previsão.
- `/itinerarios.html` — pesquisa das linhas e itinerários completos, separados por sentido (saída do terminal e saída do bairro).
- `/horarios.html` — consulta dos horários por linha e por tipo de dia, com os sentidos de saída do terminal e saída do bairro.
- `/login.html` e `/cadastro.html` — layout dividido de autenticação.


### Dados conectados
As telas agora são dirigidas por `js/data.js` e manipuladas por `js/main.js`. Os itinerários e horários foram alimentados pelos arquivos fornecidos para o projeto.
- Rastreamento: busca/filtros, seleção de ônibus, marcadores e atualização simulada de velocidade.
- Itinerários: pesquisa dinâmica das linhas.
- Horários: filtros de linha e dia.
- Home: contadores alimentados pelos dados.

Para dados reais, troque o objeto `BUS_DATA` por `fetch()` para sua API. O formato dos objetos já está separado para facilitar essa substituição.


### Cena cinematográfica da página inicial
A home ganhou uma cena inspirada em tomadas de ônibus/trem vistas pela janela: céu, prédios, árvores e rastros de luz usam velocidades diferentes para criar profundidade e sensação de movimento. O efeito reage ao scroll e inclui moldura, reflexos, vinheta e granulação cinematográfica.
