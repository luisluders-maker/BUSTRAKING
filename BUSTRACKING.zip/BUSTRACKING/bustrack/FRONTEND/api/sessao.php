<?php
// api/sessao.php — diz quem está logado (ou null). O site usa isto no cabeçalho.
// O perfil é relido do banco: se o admin promoveu alguém a MOTORISTA, basta
// recarregar a página (não precisa sair e entrar de novo).

require __DIR__ . '/conexao.php';
require __DIR__ . '/auth.php';

exigir_metodo('GET');

$usuario = usuario_atual();
if ($usuario) {
    try {
        $busca = $pdo->prepare(
            'SELECT u.Nome, p.NM_Perfil FROM Usuario u JOIN Perfil p ON p.ID_Perfil = u.ID_Perfil WHERE u.ID_Usuario = ?'
        );
        $busca->execute([$usuario['id']]);
        $linha = $busca->fetch();
        if (!$linha) {                        // conta apagada: encerra a sessão
            $_SESSION = [];
            session_destroy();
            $usuario = null;
        } else {
            $_SESSION['usuario']['perfil'] = $linha['NM_Perfil'];
            $_SESSION['usuario']['nome']   = $linha['Nome'];
            $usuario = $_SESSION['usuario'];
        }
    } catch (Throwable $e) {
        error_log('sessao.php: ' . $e->getMessage());   // em caso de erro, mantém o que a sessão já tinha
    }
}

responder(['usuario' => $usuario]);
