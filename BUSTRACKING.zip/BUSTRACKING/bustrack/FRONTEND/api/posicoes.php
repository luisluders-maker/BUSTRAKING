<?php
// api/posicoes.php — posições ao vivo dos ônibus (para a página Rastrear e a home).
// Público (qualquer visitante vê o mapa). Só lê; quem escreve é motorista/posicao.php.

require __DIR__ . '/auth.php';
require __DIR__ . '/rastreio.php';

exigir_metodo('GET');

try {
    $agora  = time();
    $onibus = [];
    foreach (rastreio_ler() as $p) {
        $onibus[] = [
            'id'         => (int) $p['veiculo'],
            'placa'      => $p['placa'],
            'linha'      => (string) $p['linha'],
            'linhaNome'  => $p['linhaNome'],
            'sentido'    => $p['sentido'],
            'lat'        => $p['lat'],
            'lng'        => $p['lng'],
            'velocidade' => $p['vel'],
            'idade'      => max(0, $agora - (int) $p['ts']),   // segundos desde a última posição
        ];
    }
    usort($onibus, fn($a, $b) => [$a['linha'], $a['placa']] <=> [$b['linha'], $b['placa']]);
    responder(['onibus' => $onibus, 'ttl' => RASTREIO_TTL]);
} catch (Throwable $e) {
    error_log('posicoes.php: ' . $e->getMessage());
    responder(['erro' => 'Não foi possível ler as posições.'], 500);
}
