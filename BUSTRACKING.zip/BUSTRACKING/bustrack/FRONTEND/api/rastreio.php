<?php
// api/rastreio.php — onde ficam as posições ao vivo dos ônibus. NÃO usa o banco.
//
// Guarda só a ÚLTIMA posição de cada veículo, num arquivo JSON na pasta temporária
// do sistema (no XAMPP: xampp\tmp). Cada envio sobrescreve a posição anterior; quem
// para de enviar some da lista depois de TTL_SEGUNDOS. Sem histórico.
// Se o arquivo for apagado, nada se perde: os motoristas enviam de novo em segundos.

const RASTREIO_TTL = 45;   // segundos sem receber posição => o ônibus sai do mapa

function rastreio_arquivo(): string
{
    return rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'bustracking_posicoes.json';
}

/** Lê as posições ainda válidas (as vencidas são descartadas). */
function rastreio_ler(): array
{
    $caminho = rastreio_arquivo();
    if (!is_file($caminho)) {
        return [];
    }
    $f = @fopen($caminho, 'rb');
    if (!$f) {
        return [];
    }
    flock($f, LOCK_SH);
    $texto = stream_get_contents($f);
    flock($f, LOCK_UN);
    fclose($f);
    return rastreio_limpar(json_decode((string) $texto, true));
}

/**
 * Lê, deixa $alterar mexer e grava — tudo sob trava exclusiva, para dois motoristas
 * enviando ao mesmo tempo não se atropelarem. $alterar recebe o array por referência
 * e devolve o que quiser repassar ao chamador.
 */
function rastreio_alterar(callable $alterar)
{
    $f = fopen(rastreio_arquivo(), 'c+b');
    if (!$f) {
        throw new RuntimeException('Não foi possível abrir ' . rastreio_arquivo());
    }
    try {
        flock($f, LOCK_EX);
        $dados = rastreio_limpar(json_decode((string) stream_get_contents($f), true));
        $retorno = $alterar($dados);
        ftruncate($f, 0);
        rewind($f);
        fwrite($f, json_encode($dados, JSON_UNESCAPED_UNICODE));
        fflush($f);
        return $retorno;
    } finally {
        flock($f, LOCK_UN);
        fclose($f);
    }
}

function rastreio_limpar($dados): array
{
    if (!is_array($dados)) {
        return [];
    }
    $limite = time() - RASTREIO_TTL;
    return array_filter($dados, fn($p) => is_array($p) && ($p['ts'] ?? 0) >= $limite);
}
