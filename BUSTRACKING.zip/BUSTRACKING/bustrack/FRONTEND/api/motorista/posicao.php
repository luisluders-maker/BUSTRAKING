<?php
// api/motorista/posicao.php — o celular do motorista manda a posição por aqui.
// POST JSON {"acao":"enviar","veiculo":ID,"linha":"101","sentido":"TERMINAL",
//            "lat":-22.35,"lng":-47.38,"velocidade":28.5}
// POST JSON {"acao":"parar","veiculo":ID}
// Só MOTORISTA ou ADMIN. A posição vai para a memória (rastreio.php), não para o banco.

require __DIR__ . '/../conexao.php';
require __DIR__ . '/../auth.php';
require __DIR__ . '/../rastreio.php';

exigir_metodo('POST');
$eu = exigir_motorista($pdo);
$e  = entrada_json();

$acao      = campo_texto($e, 'acao');
$idVeiculo = filter_var($e['veiculo'] ?? null, FILTER_VALIDATE_INT);
if (!in_array($acao, ['enviar', 'parar'], true) || !$idVeiculo || $idVeiculo < 1) {
    responder(['erro' => 'Requisição inválida.'], 422);
}

try {
    // ---------- encerrar viagem ----------
    if ($acao === 'parar') {
        rastreio_alterar(function (array &$dados) use ($idVeiculo, $eu) {
            $atual = $dados[$idVeiculo] ?? null;
            if ($atual && ((int) $atual['motorista'] === $eu['id'] || $eu['perfil'] === 'ADMIN')) {
                unset($dados[$idVeiculo]);
            }
        });
        responder(['sucesso' => true]);
    }

    // ---------- enviar posição ----------
    $num = fn($v, $min, $max) => (is_int($v) || is_float($v)) && is_finite((float) $v) && $v >= $min && $v <= $max;

    $lat = $e['lat'] ?? null;
    $lng = $e['lng'] ?? null;
    $vel = $e['velocidade'] ?? 0;
    if ($vel === null) {
        $vel = 0;
    }
    if (!$num($lat, -90, 90) || !$num($lng, -180, 180) || !$num($vel, 0, 10000)) {
        responder(['erro' => 'Posição inválida.'], 422);
    }
    $vel = round(min((float) $vel, 150), 1);   // ônibus urbano: trava absurdos em 150 km/h

    $sentido = campo_texto($e, 'sentido');
    if (!in_array($sentido, ['TERMINAL', 'BAIRRO'], true)) {
        responder(['erro' => 'Sentido inválido.'], 422);
    }

    $v = $pdo->prepare('SELECT Placa FROM Veiculo WHERE ID_Veiculo = ? AND Status = 1');
    $v->execute([$idVeiculo]);
    $placa = $v->fetchColumn();
    if ($placa === false) {
        responder(['erro' => 'Veículo não encontrado ou inativo.'], 404);
    }

    $l = $pdo->prepare('SELECT Nome FROM Linhas WHERE NUM_Linha = ? AND Status = 1');
    $l->execute([campo_texto($e, 'linha')]);
    $linhaNome = $l->fetchColumn();
    if ($linhaNome === false) {
        responder(['erro' => 'Linha não encontrada ou inativa.'], 404);
    }

    $ocupado = rastreio_alterar(function (array &$dados) use ($idVeiculo, $eu, $placa, $linhaNome, $e, $sentido, $lat, $lng, $vel) {
        $atual = $dados[$idVeiculo] ?? null;
        if ($atual && (int) $atual['motorista'] !== $eu['id']) {
            return true;   // outro motorista está com este veículo agora
        }
        $dados[$idVeiculo] = [
            'veiculo'   => $idVeiculo,
            'placa'     => $placa,
            'linha'     => campo_texto($e, 'linha'),
            'linhaNome' => $linhaNome,
            'sentido'   => $sentido,
            'lat'       => round((float) $lat, 6),
            'lng'       => round((float) $lng, 6),
            'vel'       => $vel,
            'motorista' => $eu['id'],
            'ts'        => time(),   // hora do SERVIDOR; o relógio do celular não é confiável
        ];
        return false;
    });

    if ($ocupado) {
        responder(['erro' => 'Este veículo já está em uso por outro motorista.'], 409);
    }
    responder(['sucesso' => true]);

} catch (Throwable $ex) {
    error_log('motorista/posicao.php: ' . $ex->getMessage());
    responder(['erro' => 'Não foi possível registrar a posição.'], 500);
}
