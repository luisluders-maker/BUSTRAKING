<?php
// api/motorista/veiculos.php — o que o motorista pode escolher: veículos ativos e linhas.
// Só MOTORISTA ou ADMIN. Também diz quais veículos já estão sendo usados por outra pessoa.

require __DIR__ . '/../conexao.php';
require __DIR__ . '/../auth.php';
require __DIR__ . '/../rastreio.php';

exigir_metodo('GET');
$eu = exigir_motorista($pdo);

try {
    $ao_vivo = rastreio_ler();   // [id_veiculo => posição]

    $veiculos = [];
    foreach ($pdo->query('SELECT ID_Veiculo, Placa, TP_Veiculo, Modelo FROM Veiculo WHERE Status = 1 ORDER BY Placa') as $v) {
        $uso = $ao_vivo[$v['ID_Veiculo']] ?? null;
        $veiculos[] = [
            'id'     => (int) $v['ID_Veiculo'],
            'placa'  => $v['Placa'],
            'modelo' => trim($v['TP_Veiculo'] . ' ' . $v['Modelo']),
            // ocupado = em uso por OUTRO motorista (o próprio pode retomar a viagem)
            'ocupado' => $uso !== null && (int) $uso['motorista'] !== $eu['id'],
        ];
    }

    $linhas = [];
    foreach ($pdo->query('SELECT NUM_Linha, Nome FROM Linhas WHERE Status = 1 ORDER BY NUM_Linha') as $l) {
        $linhas[] = ['numero' => (string) $l['NUM_Linha'], 'nome' => $l['Nome']];
    }

    responder(['veiculos' => $veiculos, 'linhas' => $linhas]);
} catch (Throwable $e) {
    error_log('motorista/veiculos.php: ' . $e->getMessage());
    responder(['erro' => 'Não foi possível carregar veículos e linhas.'], 500);
}
