<?php
// api/dados.php — lê o banco e devolve linhas (com itinerários) e horários em JSON,
// no mesmo formato que o js/data.js usava (BUS_DATA).

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

require __DIR__ . '/conexao.php';

try {
    // ---------- Linhas + itinerários (pontos na ordem, por sentido) ----------
    $sql = "SELECT l.NUM_Linha, l.Nome, ppl.Sentido, p.NM_Parada
            FROM Linhas l
            JOIN Pontos_parada_Linhas ppl ON ppl.ID_Linhas = l.ID_Linha
            JOIN Pontos_parada p          ON p.ID_Parada   = ppl.ID_Parada
            WHERE l.Status = 1
            ORDER BY l.NUM_Linha, FIELD(ppl.Sentido, 'TERMINAL', 'BAIRRO'), ppl.Ordem";

    $linhas = [];
    foreach ($pdo->query($sql) as $r) {
        $id = (string) $r['NUM_Linha'];
        $s  = $r['Sentido'];

        if (!isset($linhas[$id])) {
            $linhas[$id] = ['id' => $id, 'name' => $r['Nome'], 'directions' => []];
        }
        if (!isset($linhas[$id]['directions'][$s])) {
            $linhas[$id]['directions'][$s] = [
                'direction' => $s === 'TERMINAL' ? 'Saída do Terminal' : 'Saída do Bairro',
                'stops'     => [],
            ];
        }
        $linhas[$id]['directions'][$s]['stops'][] = $r['NM_Parada'];
    }
    foreach ($linhas as &$linha) {
        $linha['directions'] = array_values($linha['directions']);
    }
    unset($linha);

    // ---------- Horários por linha, dia e sentido ----------
    $sql = "SELECT l.NUM_Linha, l.Nome, h.Tipo_Dia, h.Sentido, h.HR_Saida
            FROM Linhas l
            JOIN Horarios_Linhas hl ON hl.ID_Linha    = l.ID_Linha
            JOIN Horarios h         ON h.ID_Horario   = hl.ID_Horarios
            WHERE l.Status = 1
            ORDER BY l.NUM_Linha, h.HR_Saida";

    $dias = ['segunda_sexta', 'sabado', 'domingo', 'feriado'];
    $horarios = [];
    foreach ($pdo->query($sql) as $r) {
        $id = (string) $r['NUM_Linha'];
        if (!isset($horarios[$id])) {
            $horarios[$id] = [
                'id'   => $id,
                'name' => $r['Nome'],
                'days' => array_fill_keys($dias, ['terminal' => [], 'bairro' => []]),
            ];
        }
        $horarios[$id]['days'][strtolower($r['Tipo_Dia'])][strtolower($r['Sentido'])][] = $r['HR_Saida'];
    }

    $cidade = $pdo->query('SELECT NM_Cidade FROM Cidade ORDER BY ID_Cidade LIMIT 1')->fetchColumn();

    echo json_encode([
        'city'      => $cidade ?: '',
        'lines'     => array_values($linhas),
        'schedules' => array_values($horarios),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

} catch (PDOException $e) {
    error_log('dados.php: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['erro' => 'Erro ao consultar o banco de dados.']);
}
