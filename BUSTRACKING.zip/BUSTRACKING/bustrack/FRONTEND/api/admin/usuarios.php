<?php
// api/admin/usuarios.php — lista usuários COMUNS e MOTORISTAS e troca o perfil entre os dois. Só ADMIN.
// GET                                          -> lista (nunca mostra ADMIN nem a coluna Senha)
// POST JSON {"acao":"perfil","id":N,"perfil":"USUARIO" | "MOTORISTA"}
// A checagem é feita aqui no servidor, em toda chamada: esconder o botão no JavaScript não protege nada.

require __DIR__ . '/../conexao.php';
require __DIR__ . '/../auth.php';

exigir_admin();   // 401 se não estiver logado, 403 se não for ADMIN

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $lista = $pdo->query(
            "SELECT u.ID_Usuario, u.Nome, u.Email, p.NM_Perfil
               FROM Usuario u
               JOIN Perfil p ON p.ID_Perfil = u.ID_Perfil
              WHERE p.NM_Perfil IN ('USUARIO', 'MOTORISTA')
              ORDER BY u.Nome"
        )->fetchAll();   // a coluna Senha nunca sai do servidor

        responder(['usuarios' => array_map(fn($u) => [
            'id'     => (int) $u['ID_Usuario'],
            'nome'   => $u['Nome'],
            'email'  => $u['Email'],
            'perfil' => $u['NM_Perfil'],
        ], $lista)]);
    }

    exigir_metodo('POST');
    $e      = entrada_json();
    $id     = filter_var($e['id'] ?? null, FILTER_VALIDATE_INT);
    $perfil = campo_texto($e, 'perfil');

    if (campo_texto($e, 'acao') !== 'perfil' || !$id || !in_array($perfil, ['USUARIO', 'MOTORISTA'], true)) {
        responder(['erro' => 'Requisição inválida.'], 422);
    }

    // Só mexe em quem hoje é USUARIO ou MOTORISTA: nunca em ADMIN (nem em si mesmo).
    $alvo = $pdo->prepare(
        "SELECT 1 FROM Usuario u JOIN Perfil p ON p.ID_Perfil = u.ID_Perfil
          WHERE u.ID_Usuario = ? AND p.NM_Perfil IN ('USUARIO', 'MOTORISTA')"
    );
    $alvo->execute([$id]);
    if (!$alvo->fetchColumn()) {
        responder(['erro' => 'Usuário não encontrado.'], 404);
    }

    $novo = $pdo->prepare('SELECT ID_Perfil FROM Perfil WHERE NM_Perfil = ?');
    $novo->execute([$perfil]);
    $idPerfil = $novo->fetchColumn();
    if ($idPerfil === false) {
        responder(['erro' => 'O perfil ' . $perfil . ' não existe no banco. Importe o 02_perfil_motorista.sql.'], 500);
    }

    $pdo->prepare('UPDATE Usuario SET ID_Perfil = ? WHERE ID_Usuario = ?')->execute([$idPerfil, $id]);
    responder(['sucesso' => true, 'perfil' => $perfil]);

} catch (Throwable $e) {
    error_log('admin/usuarios.php: ' . $e->getMessage());
    responder(['erro' => 'Não foi possível processar o pedido.'], 500);
}
