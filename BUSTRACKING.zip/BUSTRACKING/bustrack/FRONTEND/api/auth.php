<?php
// api/auth.php — funções de sessão e resposta usadas pelos outros arquivos da pasta api.
// Uso: require __DIR__ . '/auth.php';

/** Inicia a sessão (o "crachá" do usuário logado) com cookie mais seguro. */
function iniciar_sessao(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    session_name('BUSTRACKING');
    session_set_cookie_params([
        'lifetime' => 0,                       // some quando o navegador fecha
        'path'     => '/',
        'httponly' => true,                    // o JavaScript não consegue ler o cookie
        'samesite' => 'Lax',                   // não é enviado por formulários de outros sites
        // Atrás do túnel (Cloudflare) o PHP recebe HTTP puro, mas o navegador está em HTTPS.
        'secure'   => !empty($_SERVER['HTTPS'])
                      || strtolower($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https',
    ]);
    session_start();
}

/** Envia a resposta em JSON e encerra o script. */
function responder(array $dados, int $codigo = 200): void
{
    http_response_code($codigo);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($dados, JSON_UNESCAPED_UNICODE);
    exit;
}

/** Só aceita o método HTTP indicado (POST, GET...). */
function exigir_metodo(string $metodo): void
{
    if ($_SERVER['REQUEST_METHOD'] !== $metodo) {
        header('Allow: ' . $metodo);
        responder(['erro' => 'Método não permitido.'], 405);
    }
}

/**
 * Lê o corpo da requisição (JSON). Exigir "application/json" também ajuda a
 * barrar formulários forjados vindos de outros sites (CSRF).
 */
function entrada_json(): array
{
    $tipo = $_SERVER['CONTENT_TYPE'] ?? '';
    if (stripos($tipo, 'application/json') !== 0) {
        responder(['erro' => 'Requisição inválida.'], 415);
    }
    $dados = json_decode(file_get_contents('php://input'), true);
    return is_array($dados) ? $dados : [];
}

/** Pega um campo de texto da entrada, sem espaços nas pontas. */
function campo_texto(array $entrada, string $chave): string
{
    $valor = $entrada[$chave] ?? '';
    return is_string($valor) ? trim($valor) : '';
}

/** Usuário logado (array) ou null. */
function usuario_atual(): ?array
{
    iniciar_sessao();
    return $_SESSION['usuario'] ?? null;
}

/** Barra quem não está logado. */
function exigir_login(): array
{
    $usuario = usuario_atual();
    if (!$usuario) {
        responder(['erro' => 'É preciso estar logado.'], 401);
    }
    return $usuario;
}

/** Barra quem não é ADMIN (vamos usar no painel admin). */
function exigir_admin(): array
{
    $usuario = exigir_login();
    if ($usuario['perfil'] !== 'ADMIN') {
        responder(['erro' => 'Acesso negado.'], 403);
    }
    return $usuario;
}

/**
 * Barra quem não é MOTORISTA (ADMIN também pode). O perfil é conferido NO BANCO a
 * cada chamada: se o admin tirar o perfil de alguém, o efeito é imediato,
 * sem esperar a pessoa sair e entrar de novo.
 */
function exigir_motorista(PDO $pdo): array
{
    $usuario = exigir_login();

    $busca = $pdo->prepare(
        'SELECT p.NM_Perfil FROM Usuario u JOIN Perfil p ON p.ID_Perfil = u.ID_Perfil WHERE u.ID_Usuario = ?'
    );
    $busca->execute([$usuario['id']]);
    $perfil = $busca->fetchColumn();

    if ($perfil === false) {                 // usuário apagado do banco
        $_SESSION = [];
        session_destroy();
        responder(['erro' => 'É preciso estar logado.'], 401);
    }
    $_SESSION['usuario']['perfil'] = $perfil;

    if (!in_array($perfil, ['MOTORISTA', 'ADMIN'], true)) {
        responder(['erro' => 'Acesso negado: área só para motoristas.'], 403);
    }
    return $_SESSION['usuario'];
}
