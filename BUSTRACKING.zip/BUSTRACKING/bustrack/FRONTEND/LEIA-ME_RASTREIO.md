# Rastreio ao vivo com celular + Cloudflare Tunnel

## Como funciona
- O **motorista** abre `motorista.html` no celular, escolhe veículo/linha/sentido e toca em **Iniciar viagem**.
  O navegador envia latitude, longitude e velocidade a cada 4 s para `api/motorista/posicao.php`.
- O servidor guarda **só a última posição** de cada veículo num arquivo temporário
  (`bustracking_posicoes.json`, na pasta temporária do sistema). **Nada vai para o banco.**
  Quem para de enviar some do mapa em ~45 s.
- Qualquer visitante abre `rastrear.html` e vê os ônibus no mapa (OpenStreetMap), atualizado a cada 4 s.

## Perfis
| Perfil    | O que pode                                         |
|-----------|----------------------------------------------------|
| USUARIO   | Ver o site e o rastreio                            |
| MOTORISTA | Tudo do usuário + **Modo motorista** (enviar GPS)  |
| ADMIN     | Tudo + Painel admin (trocar o perfil dos usuários) |

Contas de teste (troque as senhas antes de publicar):
`admin@bustracking.example / admin123`, `motorista@bustracking.example / motorista123`.
Para criar um motorista: a pessoa se cadastra normalmente e o ADMIN troca o perfil dela em **Painel admin**.

## Banco de dados
- Banco já existente: importe `01_remover_rastreador.sql` e depois `02_perfil_motorista.sql`.
- Banco do zero: importe `BusTracking_MySQL.sql` e depois `BusTracking_Dados.sql`.

## Por que o túnel?
O GPS do celular **só funciona em páginas HTTPS**. O Cloudflare Tunnel dá um endereço `https://` público
para o site que roda no seu PC (sem conta, de graça).

## Passo a passo
1. Instale uma vez (PowerShell): `winget install --id Cloudflare.cloudflared`
2. Abra o **XAMPP** e ligue o **MySQL** (o Apache não é necessário).
3. Dê dois cliques em **`iniciar_site_publico.bat`** (nesta pasta).
   Ele abre um servidor PHP só com esta pasta e o túnel.
4. Na janela do túnel aparece `https://alguma-coisa.trycloudflare.com`. Abra esse endereço no celular,
   entre como motorista, vá em **Modo motorista** e toque em **Iniciar viagem** (aceite a permissão de localização).
5. No computador, abra o mesmo endereço em `/rastrear.html`: o ônibus aparece e se mexe no mapa.

O endereço **muda toda vez** que você inicia o túnel. O PC precisa ficar ligado e com internet.

## Segurança
- Use o `.bat` (servidor PHP só desta pasta). **Não** aponte o túnel para o Apache do XAMPP:
  o phpMyAdmin e o painel do XAMPP ficariam acessíveis por quem tiver o link, e o MySQL do XAMPP
  vem com o usuário `root` sem senha.
- Só MOTORISTA e ADMIN conseguem enviar posição; isso é conferido no servidor a cada envio.
- Um veículo só pode ser usado por um motorista por vez.

## Se algo der errado
- *`failed to dial to edge with quic: timeout`*: a rede está bloqueando QUIC (UDP). O `.bat` já usa
  `--protocol http2` (TCP) para evitar isso. Se ainda falhar, teste em outra rede (ex.: hotspot do celular)
  e confira se o firewall/antivírus não está bloqueando o `cloudflared`.
- *"O GPS só funciona em HTTPS"*: você abriu o endereço `http://...`; use o `https://` do túnel.
- *Permissão negada*: no celular, libere a localização para o navegador/site.
- *Para de enviar quando a tela apaga*: mantenha a tela ligada (a página tenta segurá-la sozinha).
- *O mapa fica vazio*: ninguém está enviando posição (o aviso "Nenhum ônibus em operação agora" aparece).
