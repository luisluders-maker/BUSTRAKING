/* =========================================================
   BUSTRACKING — Comportamentos compartilhados
   ========================================================= */

const $ = (selector, context = document) => context.querySelector(selector);
const $$ = (selector, context = document) => [...context.querySelectorAll(selector)];

/** Escapa texto antes de inseri-lo em HTML gerado pelo JavaScript. */
const escapeHTML = (value) => String(value).replace(/[&<>"']/g, (character) => ({
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#039;'
}[character]));

/** Configura o menu móvel presente no cabeçalho de cada página. */
function loadHeader() {
  const headerTarget = $('[data-header]');
  if (!headerTarget) return;
  setupMobileMenu(headerTarget);
}

function setupMobileMenu(context) {
  const toggle = $('.menu-toggle', context);
  const menu = $('#mobile-menu', context);
  if (!toggle || !menu) return;

  toggle.addEventListener('click', () => {
    const isOpen = toggle.getAttribute('aria-expanded') === 'true';
    toggle.setAttribute('aria-expanded', String(!isOpen));
    toggle.setAttribute('aria-label', isOpen ? 'Abrir menu' : 'Fechar menu');
    menu.hidden = isOpen;
  });

  $$('a', menu).forEach((link) => {
    link.addEventListener('click', () => {
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'Abrir menu');
      menu.hidden = true;
    });
  });
}

/**
 * Busca linhas, itinerários e horários no banco (via api/dados.php) e coloca em
 * BUS_DATA. Se a API não responder, o site continua com o que veio do data.js.
 * (Os ônibus em tempo real ainda vêm do data.js.)
 */
async function carregarDados() {
  try {
    const resposta = await fetch('api/dados.php', { cache: 'no-store' });
    if (!resposta.ok) throw new Error(`HTTP ${resposta.status}`);

    const dados = await resposta.json();
    if (dados.erro) throw new Error(dados.erro);

    BUS_DATA.lines = dados.lines;
    BUS_DATA.schedules = dados.schedules;
  } catch (erro) {
    console.warn('Não foi possível carregar os dados do banco; usando o data.js.', erro);
  }
}

/* ---------------------------------------------------------
   LOGIN / CADASTRO / SESSÃO (conversa com a pasta api/)
   --------------------------------------------------------- */

/** Descobre quem está logado (api/sessao.php) e guarda em window.USUARIO. */
async function carregarSessao() {
  try {
    const resposta = await fetch('api/sessao.php', { cache: 'no-store' });
    const dados = await resposta.json();
    window.USUARIO = dados.usuario || null;
  } catch (erro) {
    window.USUARIO = null; // sem PHP (ou fora do ar): trata como visitante
  }
}

/** Encerra a sessão e volta para a página inicial. */
async function sair() {
  try {
    await fetch('api/logout.php', { method: 'POST' });
  } catch (erro) {
    console.warn('Não foi possível encerrar a sessão no servidor.', erro);
  }
  window.location.href = 'index.html';
}

/** Troca "Entrar / Criar conta" por "Olá, nome / Sair" quando há alguém logado. */
function atualizarCabecalho() {
  const usuario = window.USUARIO;
  if (!usuario) return;

  const primeiroNome = String(usuario.nome).trim().split(/\s+/)[0];

  // Atalho para o painel: só aparece para ADMIN (a proteção de verdade é feita no PHP).
  const ehAdmin = usuario.perfil === 'ADMIN';
  // MOTORISTA (e ADMIN) enxergam o atalho para enviar a posição do ônibus.
  const podeDirigir = ehAdmin || usuario.perfil === 'MOTORISTA';

  const acoes = $('.header-actions');
  if (acoes) {
    acoes.innerHTML = `
      ${podeDirigir ? '<a class="btn btn-ghost btn-sm" href="motorista.html">Modo motorista</a>' : ''}
      ${ehAdmin ? '<a class="btn btn-ghost btn-sm" href="admin.html">Painel admin</a>' : ''}
      <span style="font-weight:600;margin-inline-end:.25rem;color:rgb(255 255 255 / 90%);white-space:nowrap;max-inline-size:9rem;overflow:hidden;text-overflow:ellipsis">Olá, ${escapeHTML(primeiroNome)}</span>
      <button class="btn btn-ghost btn-sm" type="button" data-logout>Sair</button>
    `;
  }

  const menuMovel = $('#mobile-menu ul');
  if (menuMovel) {
    $$('a[href="login.html"], a[href="cadastro.html"]', menuMovel).forEach((link) => link.closest('li')?.remove());
    if (podeDirigir) menuMovel.insertAdjacentHTML('beforeend', '<li><a href="motorista.html">Modo motorista</a></li>');
    if (ehAdmin) menuMovel.insertAdjacentHTML('beforeend', '<li><a href="admin.html">Painel admin</a></li>');
    menuMovel.insertAdjacentHTML('beforeend', `<li><a href="#" data-logout>Sair (${escapeHTML(primeiroNome)})</a></li>`);
  }

  $$('[data-logout]').forEach((elemento) => {
    elemento.addEventListener('click', (evento) => {
      evento.preventDefault();
      sair();
    });
  });
}

/** Liga os formulários de login.html e cadastro.html ao PHP. */
function formulariosAuth() {
  const form = $('form.form');
  if (!form || !$('#email', form) || !$('#password', form)) return;

  const ehCadastro = Boolean($('#name', form));
  const botao = $('button[type="submit"]', form);

  // Área onde aparecem os avisos (erro em vermelho, sucesso em verde).
  const aviso = document.createElement('p');
  aviso.setAttribute('role', 'alert');
  aviso.hidden = true;
  aviso.style.cssText = 'margin:.25rem 0 0;font-size:.9rem;font-weight:600;';
  botao.insertAdjacentElement('beforebegin', aviso);

  const mostrar = (texto, sucesso = false) => {
    aviso.hidden = false;
    aviso.textContent = texto;
    aviso.style.color = sucesso ? 'var(--success)' : 'var(--danger)';
  };

  const enviar = async (arquivo, corpo) => {
    const resposta = await fetch(`api/${arquivo}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(corpo)
    });
    const dados = await resposta.json().catch(() => ({}));
    return { ok: resposta.ok, dados };
  };

  form.addEventListener('submit', async (evento) => {
    evento.preventDefault();
    aviso.hidden = true;

    const email = $('#email', form).value.trim();
    const senha = $('#password', form).value;
    const textoOriginal = botao.textContent;
    let concluido = false; // true = vai trocar de página; mantém o botão travado
    botao.disabled = true;
    botao.textContent = 'Aguarde...';

    try {
      if (ehCadastro) {
        const nome = $('#name', form).value.trim();
        const cadastro = await enviar('cadastro.php', { nome, email, senha });
        if (!cadastro.ok) {
          mostrar(cadastro.dados.erro || 'Não foi possível criar a conta.');
          return;
        }
        // Conta criada: já entra automaticamente.
        const login = await enviar('login.php', { email, senha });
        mostrar('Conta criada com sucesso!', true);
        concluido = true;
        setTimeout(() => {
          window.location.href = login.ok ? 'index.html' : 'login.html';
        }, 900);
      } else {
        const login = await enviar('login.php', { email, senha });
        if (!login.ok) {
          mostrar(login.dados.erro || 'Não foi possível entrar.');
          return;
        }
        concluido = true;
        window.location.href = 'index.html';
      }
    } catch (erro) {
      mostrar('Não foi possível conectar ao servidor. Verifique se o Apache está ligado.');
    } finally {
      if (!concluido) {
        botao.disabled = false;
        botao.textContent = textoOriginal;
      }
    }
  });
}

/** Atualiza as estatísticas exibidas na página inicial (ônibus ao vivo vêm de api/posicoes.php). */
async function homeStats() {
  const busCount = $('#bus-count');
  const lineCount = $('#line-count');
  if (!busCount || !lineCount || !window.BUS_DATA) return;

  lineCount.textContent = BUS_DATA.lines.length;
  try {
    const resposta = await fetch('api/posicoes.php', { cache: 'no-store' });
    const dados = await resposta.json();
    busCount.textContent = Array.isArray(dados.onibus) ? dados.onibus.length : 0;
  } catch (erro) {
    busCount.textContent = '0';
  }
}

/**
 * Rastreamento ao vivo: mapa real (Leaflet + OpenStreetMap) com as posições que os
 * motoristas enviam pelo celular. As posições vêm de api/posicoes.php (memória do
 * servidor, nada é guardado no banco) e são atualizadas a cada poucos segundos.
 */
function tracking() {
  const list = $('#busList');
  const mapEl = $('#liveMap');
  if (!list || !mapEl || !window.L) return;

  const INTERVALO_MS = 4000;
  const VELOCIDADE_PARADO = 2;          // abaixo disso (km/h) o ônibus é considerado parado
  const CENTRO = [-22.357, -47.384];    // Araras-SP

  const mapa = L.map(mapEl).setView(CENTRO, 14);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
  }).addTo(mapa);
  window.addEventListener('load', () => mapa.invalidateSize());

  const camada = L.layerGroup().addTo(mapa);
  const marcadores = new Map();   // id do veículo -> marcador
  let onibus = [];
  let selecionado = null;
  let enquadrou = false;          // ajusta o zoom aos ônibus só na primeira vez

  const status = (bus) => (bus.velocidade >= VELOCIDADE_PARADO ? 'Em operação' : 'Parado');
  const sentidoTexto = (bus) => (bus.sentido === 'TERMINAL' ? 'Saída do Terminal' : 'Saída do Bairro');
  const idadeTexto = (bus) => (bus.idade < 5 ? 'agora' : `há ${bus.idade} s`);
  const kmh = (bus) => Math.round(bus.velocidade);

  const popup = (bus) => `
    <strong>Linha ${escapeHTML(bus.linha)}</strong><br>
    <span>${escapeHTML(bus.linhaNome)}</span>
    <div class="popup-row"><span>Sentido</span><b>${escapeHTML(sentidoTexto(bus))}</b></div>
    <div class="popup-row"><span>Veículo</span><b>${escapeHTML(bus.placa)}</b></div>
    <div class="popup-row"><span>Velocidade</span><b>${kmh(bus)} km/h</b></div>
    <div class="popup-row"><span>Atualizado</span><b>${idadeTexto(bus)}</b></div>`;

  const icone = (bus, ativo) => L.divIcon({
    className: 'bus-pin-wrap',
    html: `<span class="bus-pin${ativo ? ' active' : ''}${status(bus) === 'Parado' ? ' parado' : ''}">${escapeHTML(bus.linha)}</span>`,
    iconSize: [44, 44],
    iconAnchor: [22, 22],
    popupAnchor: [0, -22]
  });

  const filtrados = () => {
    const consulta = ($('#busSearch')?.value || '').trim().toLowerCase();
    const filtroStatus = $('#statusFilter')?.value || '';
    const filtroLinha = $('#lineFilter')?.value || '';
    return onibus.filter((bus) =>
      (!consulta || `${bus.linha} ${bus.linhaNome} ${bus.placa} ${sentidoTexto(bus)}`.toLowerCase().includes(consulta)) &&
      (!filtroStatus || status(bus) === filtroStatus) &&
      (!filtroLinha || bus.linha === filtroLinha));
  };

  const atualizarFiltroLinhas = () => {
    const select = $('#lineFilter');
    if (!select) return;
    const atual = select.value;
    const linhas = [...new Set(onibus.map((bus) => bus.linha))].sort((x, y) => Number(x) - Number(y));
    select.innerHTML = '<option value="">Todas as linhas</option>' +
      linhas.map((n) => `<option value="${escapeHTML(n)}">Linha ${escapeHTML(n)}</option>`).join('');
    select.value = linhas.includes(atual) ? atual : '';
  };

  const selecionar = (id, { voar = true } = {}) => {
    selecionado = id;
    const marcador = marcadores.get(id);
    const bus = onibus.find((item) => item.id === id);
    if (marcador && bus) {
      marcador.setPopupContent(popup(bus));
      marcador.openPopup();
      if (voar) mapa.flyTo(marcador.getLatLng(), Math.max(mapa.getZoom(), 16), { duration: 0.6 });
    }
    desenhar();
  };

  const desenhar = () => {
    const visiveis = filtrados();
    const ids = new Set(visiveis.map((bus) => bus.id));

    // Barra lateral
    list.innerHTML = visiveis.map((bus) => `
      <article class="bus-item ${bus.id === selecionado ? 'active' : ''}" data-bus="${bus.id}">
        <div class="bus-row">
          <span class="bus-number">${escapeHTML(bus.linha)}</span>
          <div>
            <strong>Linha ${escapeHTML(bus.linha)}</strong><br>
            <small>${status(bus)} · ${kmh(bus)} km/h</small>
          </div>
        </div>
        <small>${escapeHTML(bus.linhaNome)} · ${escapeHTML(sentidoTexto(bus))}</small><br>
        <small>${escapeHTML(bus.placa)} · atualizado ${idadeTexto(bus)}</small>
      </article>`).join('') ||
      `<p class="empty">${onibus.length ? 'Nenhum ônibus encontrado com esses filtros.' : 'Nenhum ônibus em operação agora.'}</p>`;

    // Marcadores: some quem saiu da lista (ou foi filtrado), cria e move o resto.
    marcadores.forEach((marcador, id) => {
      if (!ids.has(id)) { camada.removeLayer(marcador); marcadores.delete(id); }
    });
    visiveis.forEach((bus) => {
      let marcador = marcadores.get(bus.id);
      if (!marcador) {
        marcador = L.marker([bus.lat, bus.lng], { icon: icone(bus, bus.id === selecionado) })
          .bindPopup(popup(bus), { autoPan: false })
          .on('click', () => selecionar(bus.id, { voar: false }))
          .addTo(camada);
        marcador._estado = `${bus.id === selecionado}|${status(bus)}|${bus.linha}`;
        marcadores.set(bus.id, marcador);
      } else {
        marcador.setLatLng([bus.lat, bus.lng]);
        const estado = `${bus.id === selecionado}|${status(bus)}|${bus.linha}`;
        if (marcador._estado !== estado) marcador.setIcon(icone(bus, bus.id === selecionado));   // só recria o ícone se mudou
        marcador._estado = estado;
        marcador.setPopupContent(popup(bus));
      }
    });

    // Textos de resumo
    const contador = $('.live-count');
    if (contador) contador.textContent = onibus.length ? `${onibus.length} ao vivo` : 'sem ônibus';
    const tag = $('#liveTag');
    if (tag) tag.textContent = onibus.length ? `● ${onibus.length} ônibus ao vivo` : '● Nenhum ônibus ao vivo';
    const aviso = $('#mapAviso');
    if (aviso) aviso.hidden = onibus.length > 0;
  };

  const buscar = async () => {
    try {
      const resposta = await fetch('api/posicoes.php', { cache: 'no-store' });
      if (!resposta.ok) throw new Error(`HTTP ${resposta.status}`);
      const dados = await resposta.json();
      onibus = Array.isArray(dados.onibus) ? dados.onibus : [];
      if (selecionado !== null && !onibus.some((bus) => bus.id === selecionado)) selecionado = null;

      atualizarFiltroLinhas();
      desenhar();

      if (!enquadrou && onibus.length) {
        enquadrou = true;
        mapa.fitBounds(L.latLngBounds(onibus.map((bus) => [bus.lat, bus.lng])), { padding: [60, 60], maxZoom: 16 });
      }
    } catch (erro) {
      console.warn('Não foi possível atualizar as posições.', erro);
      const tag = $('#liveTag');
      if (tag) tag.textContent = '● Sem conexão com o servidor';
    }
  };

  list.addEventListener('click', (evento) => {
    const item = evento.target.closest('.bus-item');
    if (item) selecionar(Number(item.dataset.bus));
  });
  ['busSearch', 'statusFilter', 'lineFilter'].forEach((id) => {
    $(`#${id}`)?.addEventListener('input', desenhar);
    $(`#${id}`)?.addEventListener('change', desenhar);
  });

  const ciclo = async () => {
    if (!document.hidden) await buscar();   // aba escondida não precisa consultar o servidor
    window.setTimeout(ciclo, INTERVALO_MS);
  };
  ciclo();
}

function itinerarios() {
  const grid = $('#lineGrid');
  if (!grid || !window.BUS_DATA) return;

  const renderStops = (stops) => stops.map((stop, index) => `
    <li>
      <span class="stop-index" aria-hidden="true">${index + 1}</span>
      <span>${escapeHTML(stop)}</span>
    </li>
  `).join('');

  const render = () => {
    const query = ($('#lineSearch')?.value || '').trim().toLowerCase();
    const lines = BUS_DATA.lines.filter((line) =>
      `${line.id} ${line.name}`.toLowerCase().includes(query)
    );

    grid.innerHTML = lines.map((line) => `
      <article class="line-route-card">
        <header class="route-card-top">
          <span class="route-number" aria-label="Linha ${escapeHTML(line.id)}">${escapeHTML(line.id)}</span>
          <div>
            <h3 class="route-card-title">${escapeHTML(line.name)}</h3>
            <p class="route-card-sub">${line.directions.length} sentidos disponíveis</p>
          </div>
        </header>

        <section class="route-directions" aria-label="Itinerários da linha ${escapeHTML(line.id)}">
          ${line.directions.map((route) => `
            <details class="route-direction">
              <summary>
                <span>${escapeHTML(route.direction)}</span>
                <small>${route.stops.length} pontos</small>
              </summary>
              <ol class="route-stop-list">
                ${renderStops(route.stops)}
              </ol>
            </details>
          `).join('')}
        </section>
      </article>
    `).join('') || '<p class="empty">Nenhuma linha encontrada.</p>';
  };

  $('#lineSearch')?.addEventListener('input', render);
  render();
}

function horarios() {
  const rows = $('#scheduleRows');
  const lineSelect = $('#scheduleLine');
  const daySelect = $('#scheduleDay');
  const description = $('#scheduleDescription');

  if (!rows || !lineSelect || !daySelect || !window.BUS_DATA) return;

  const dayLabels = {
    segunda_sexta: 'Segunda a sexta-feira',
    sabado: 'Sábado',
    domingo: 'Domingo',
    feriado: 'Feriado'
  };

  const scheduleByLine = new Map(BUS_DATA.schedules.map((item) => [item.id, item]));

  lineSelect.innerHTML = BUS_DATA.schedules.map((schedule) => `
    <option value="${escapeHTML(schedule.id)}">Linha ${escapeHTML(schedule.id)} — ${escapeHTML(schedule.name)}</option>
  `).join('');

  const renderTimes = (times) => times.length
    ? `<ol class="schedule-times">${times.map((time) => `<li><time datetime="${escapeHTML(time)}">${escapeHTML(time)}</time></li>`).join('')}</ol>`
    : '<p class="empty compact-empty">Não há horário informado para este sentido.</p>';

  const render = () => {
    const schedule = scheduleByLine.get(lineSelect.value);
    const day = schedule?.days[daySelect.value];

    if (!schedule || !day) {
      rows.innerHTML = '<p class="empty">Nenhum horário encontrado.</p>';
      if (description) description.textContent = '';
      return;
    }

    if (description) {
      description.textContent = `${dayLabels[daySelect.value]} · ${schedule.name}`;
    }

    rows.innerHTML = `
      <article class="schedule-direction">
        <header>
          <h3>Saída do Terminal</h3>
          <span>${day.terminal.length} horários</span>
        </header>
        ${renderTimes(day.terminal)}
      </article>
      <article class="schedule-direction">
        <header>
          <h3>Saída do Bairro</h3>
          <span>${day.bairro.length} horários</span>
        </header>
        ${renderTimes(day.bairro)}
      </article>
    `;
  };

  lineSelect.addEventListener('change', render);
  daySelect.addEventListener('change', render);
  render();
}

document.addEventListener('DOMContentLoaded', async () => {
  loadHeader();
  formulariosAuth();

  // Busca sessão e (nas páginas que usam data.js) os dados do banco, em paralelo.
  await Promise.all([
    carregarSessao(),
    window.BUS_DATA ? carregarDados() : null
  ]);

  atualizarCabecalho();
  homeStats();
  tracking();
  itinerarios();
  horarios();
});
