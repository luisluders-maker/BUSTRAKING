@echo off
chcp 65001 >nul
title BUSTRACKING - site publico (Cloudflare Tunnel)
cd /d "%~dp0"

rem ---- Ajuste aqui se o XAMPP nao estiver em C:\xampp ----
set "PHP=C:\xampp\php\php.exe"

if not exist "%PHP%" (
  echo Nao encontrei o PHP em %PHP%
  echo Abra este arquivo e corrija a linha "set PHP=..." com a pasta do seu XAMPP.
  pause & exit /b 1
)
where cloudflared >nul 2>nul
if errorlevel 1 (
  echo O cloudflared nao esta instalado. Instale com:
  echo     winget install --id Cloudflare.cloudflared
  echo Depois FECHE esta janela e abra este arquivo de novo.
  pause & exit /b 1
)

echo.
echo  1^) Deixe o MySQL LIGADO no painel do XAMPP ^(o Apache nao e necessario^).
echo  2^) Vou abrir o site so desta pasta em http://127.0.0.1:8080
echo     e depois criar o endereco https publico.
echo  3^) Procure na tela a linha  https://alguma-coisa.trycloudflare.com
echo     e abra esse endereco no celular.
echo.

start "Servidor PHP do BUSTRACKING" "%PHP%" -S 127.0.0.1:8080 -t "%~dp0."
timeout /t 2 >nul
rem --protocol http2: usa TCP em vez de QUIC/UDP, que muitas redes bloqueiam
cloudflared tunnel --protocol http2 --url http://127.0.0.1:8080

echo.
echo Tunel encerrado. Feche a janela "Servidor PHP do BUSTRACKING" tambem.
pause
